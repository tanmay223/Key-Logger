Copy the code from keylogger.py .
Make a python file and save in the location.
You can either use pycharm or your command prompt to execute the code.
Once the code get started it will record every key stock of your keyboard.